#!/bin/bash

# --- Menú ----

menu()
{
	echo "--------------- Menú -----------------"
	echo "----> Opciones a ingresar:"
	echo ""
	echo "# $0 <directorio_origen> ---> directorio a realizar el backup."
	echo "# $0 <directorio_origen> [directorio_destino] ---> (opcional) directorio donde se guardará el backup. Por defecto va a /backup_dir."
	echo "# $0 -help    --->  Menú."
	echo ""
	echo "----> Ejemplo 1 :"
	echo "# $0 /var/log  ---> Sin argumento para [directorio_destino]. Hace el backup de /var/log en /backup_dir"
	echo ""
	echo "----> Ejemplo 2 :"
	echo "# $0 /www_dir /mnt/usb_backup ---> Hace el backup de /www_dir en /mnt/usb_backup"
	echo ""
	echo "-------------- Fin Menú --------------"
	echo ""
#	read -p "ingrese una opcion:" OP
	exit 0
}


# --- 2. VALIDACION DE ARGUMENTOS ---
ORIGEN_DIR="$1"
DESTINO_DIR="${2:-/backup_dir}"
#Verifico si llamo a help
if [[ $ORIGEN_DIR == "-help" ]];
then
	menu
fi
#Verifico la longitud del primer argumento ($1) es cero.
if [[ -z $ORIGEN_DIR ]];
then
	menu
fi

# --- VALIDO LA EXISTENCIA DEL DIR ORIGEN ---
#El <directorio_origen> existe, es un directorio.
echo "Validando directorio..."
if [[ ! -e $ORIGEN_DIR && ! -d $ORIGEN_DIR ]];
then
	echo "ERROR: Debe especificar un <directorio_origen> válido para realizar su backup"
	menu
fi
	

#Valido dir destino existe, sino, intento crearlo?
#Verifico si el dir origen es accesible (legible)
if [[ ! -r "$DESTINO_DIR" ]]; 
then
	echo "ADVERTENCIA: El dir de origen "$DESTINO_DIR" no tiene permisos de lectura. El backup podría fallar para algunos archivos."
fi


# --- REALIZAR EL BACKUP ---
echo "Preparando el backup..."

#Fecha
DATE_FORMAT=$(date +%Y%m%d)

#Obtengo el nombre base del dir origen (ej: "log" de "/var/log")
DIR_NAME=$(basename "$ORIGEN_DIR")

#Nombre del archivo de backup: nombre_dir_bkp_YYYYMMDD.tar.gz
OUTPUT_FILENAME="${DIR_NAME}_bkp_${DATA_FORMAT}.tar.gz"
OUTPUT_FILE="$DESTINO_DIR/$OUTPUT_FILENAME"

echo "Iniciando backup de '$ORIGEN_DIR' en '$OUTPUT_FILE'..."

#tar: comprimir y archivar
# -c: crea archivo
# -z: comprime con gzip
# -v: mostrar progreso verboso
# -f: especificar el name del archivo de salida
sudo tar -czvf "$OUTPUT_FILE" "$ORIGEN_DIR"

#Verificar si el backup fue exitoso
if [[ $? -eq 0 ]]; 
then
	echo "Backup de '$ORIGEN_DIR' completado exitosamente en '$OUTPUT_FILE'."
else
	echo "ERROR: El backup de '$ORIGEN_DIR' falló. Verifique los mjes anteriores."
fi

echo "Proceso de backup finalizado."
exit 0





























