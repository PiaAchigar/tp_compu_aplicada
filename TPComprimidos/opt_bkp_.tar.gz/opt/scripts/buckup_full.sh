#!/bin/bash
#Primer prueba de crear el archivo script, by Pía.

#Script de backup: backup_full.sh
#Ubicación: /opt/scripts
#Descripción: Comprime directorios impostantes individuales y los guarda en /media/carpeta_compartida
#Fecha de creación: 02-06-2025

#--- Configuración ---
BUCKUP_DIR="/media/carpeta_comartida"
DATE_FORMAT=$(date +%Y%m%d)
declare -a DIR_TO_BACKUP=(
	"/root"
	"/etc"
	"/opt"
	"/particiones"# Acá es donde redirijo el /proc
	"/www_dir"
	"/backup_dir"
)
#--- Verificar y crear el directorio de backup ---
if [ ! -d "$BACKUP_DIR"];
then
	echo "El directorio de destino ($BACKUP_DIR) no existe. Creándolo..."
	sudo mkdir -p "BACKUP_DIR"
	if [ $? -ne 0]; then
		echo "Error:No se puede crear el dir de destino. Verifica los permisos."
		exit 1
	fi
fi

# --- Realizar los backups individuales ---

for DIR in "${DIR_TO_BACKUO[@]}"; do
	#nombre base
	DIR_NAME=$(basename "$DIR")
	#Nombre del archivo de backup: /media/carpeta_compartida/name_dir
	OUTPUT_FILE="$BACKUP_DIR/${DIR_NAME}_${DATE_FORMAT}.tar.gz"
	
	echo "cOMPRIMIENDO $DIR EN $OUTPUT_FILE..."
	
	#tar para comprimir y archivar, -c crea archivo, -z: comprime con gzip, -f:archivo de salida
	sudo tar -czvf "$OUTPUT_FILE" "$DIR"

	#Verificar si la compresión fue exitosa
	if [$? -eq 0]; then
		echo "Backup de $DIR completo exitosamente."
	else
		echo "ERROR: Falló el backup de $DIR."
	fi
done

echo "Proceso de backup finalizado."	









	

